package com.example.zipaboutgui.domain.enums;

public enum ScooterType {
    COMMUTER,
    OFF_ROAD,
    KIDS,
    PERFORMANCE
}