package com.example.zipaboutgui.domain.enums;

public enum FrameType {
    CITY,
    HYBRID,
    MTB,
    ROAD,
    FOLDING,
    CARGO
}