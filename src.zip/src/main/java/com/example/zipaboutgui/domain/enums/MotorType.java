package com.example.zipaboutgui.domain.enums;

public enum MotorType {
    HUB_FRONT,
    HUB_REAR,
    MID_DRIVE,
    DUAL_HUB
}
