package com.example.zipaboutgui.domain.enums;

public enum RentalStatus {
    ACTIVE,
    COMPLETED,
    CANCELLED
}
