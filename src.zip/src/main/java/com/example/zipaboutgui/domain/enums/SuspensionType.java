package com.example.zipaboutgui.domain.enums;

public enum SuspensionType {
    RIGID,
    FRONT,
    REAR,
    FULL
}
