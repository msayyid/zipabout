package com.example.zipaboutgui.domain.enums;

public enum TireType {
    SLICK,
    HYBRID,
    KNOBBY,
    SOLID
}