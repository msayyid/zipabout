package com.example.zipaboutgui.domain.enums;

public enum VehicleKind {
    E_BIKE,
    E_SCOOTER,
    E_SKATEBOARD,
    SEGWAY,
    BIKE,
    KICK_SCOOTER,
    SKATEBOARD
}