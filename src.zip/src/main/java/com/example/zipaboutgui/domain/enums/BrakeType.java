package com.example.zipaboutgui.domain.enums;

public enum BrakeType {
    RIM,
    MECHANICAL_DISC,
    HYDRAULIC_DISC,
    DRUM,
    FOOT
}
