package com.example.zipaboutgui.domain.enums;

public enum EquipmentType {
    HELMET,
    KNEEPAD,
    GLOVE,
    ELBOWPAD,
    REFLECTIVE_VEST
}
