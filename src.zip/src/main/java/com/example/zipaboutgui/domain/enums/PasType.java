package com.example.zipaboutgui.domain.enums;

public enum PasType {
    CADENCE_BASED,
    TORQUE_BASED,
    COMBINED
}