package com.example.zipaboutgui.domain.enums;

public enum DisplayFeature {
    SPEED,
    RANGE,
    BATTERY_PERCENT,
    TRIP_DISTANCE,
    LIGHT_CONTROL,
    RIDE_MODE_SELECTION
}
