package com.example.zipaboutgui.domain.enums;

public enum RideMode {
    ECO,
    NORMAL,
    SPORT,
    TURBO
}
